import palindrome_metrics


def add_all_col(df):
    df['ALL']=1
    return df

def add_agyw_col(df, age_col, gender_col):
    df['EP_AGYW']=0
    df.loc[(df[age_col]>15)&(df[age_col]<25)
              &(df[gender_col]==0),'EP_AGYW'] =1
    return df

def add_abym_col(df, age_col, gender_col):
    df['EP_ABYM']=0
    df.loc[(df[age_col]>15)&(df[age_col]<25)
          &(df[gender_col]==1),'EP_ABYM'] =1
    return df

def add_children_col(df, age_col):
    df['EP_CHILDREN']=0
    df.loc[(df[age_col]<15),'EP_CHILDREN'] =1
    return df

def add_adults_col(df, age_col):
    df['EP_ADULTS']=0
    df.loc[(df[age_col]>24),'EP_ADULTS'] =1
    return df

def add_adult_females_col(df, age_col, gender_col):
    df['EP_ADULT_FEMALES']=0
    df.loc[(df[age_col]>24)&(df[gender_col]==0),'EP_ADULT_FEMALES'] =1
    return df

def add_adult_males_col(df, age_col, gender_col):
    df['EP_ADULT_MALES']=0
    df.loc[(df[age_col]>24)&(df[gender_col]==1),'EP_ADULT_MALES'] =1
    return df

def add_population_columns(df, age_col, gender_col):
    df = add_agyw_col(df, age_col, gender_col)
    df = add_abym_col(df, age_col, gender_col)
    df = add_children_col(df, age_col)
    df = add_adults_col(df, age_col)
    df = add_adult_females_col(df, age_col, gender_col)
    df = add_adult_males_col(df, age_col, gender_col)
    df = add_all_col(df)
    return df

def add_first_visit_col(df, sequence_col):
    df['EC_FIRST_VISIT']=0
    df.loc[(df[sequence_col]==1),'EC_FIRST_VISIT'] =1
    return df

def add_first_6months_col(df, sequence_col, months_col):
    df['EC_FIRST_6MONTHS']=0
    df.loc[(df[months_col]<=6)&(df[sequence_col]!=1),'EC_FIRST_6MONTHS'] =1
    return df

def add_first_12months_col(df, months_col):
    df['EC_FIRST_12MONTHS']=0
    df.loc[(df[months_col]<=12),'EC_FIRST_12MONTHS'] =1
    return df

def add_7_to_12months_col(df, months_col):
    df['EC_7_TO_12MONTHS']=0
    df.loc[(df[months_col]<=12)&(df[months_col]>6),'EC_7_TO_12MONTHS'] =1
    return df

def add_IAS_stable_patient_col(df, vl_count_col, rna_col, months_col):
    df['EC_IAS_STABLE']=0
    df.loc[((df[months_col]>=12)&(df[vl_count_col]>=2)
           &(df[rna_col]<=400)),'EC_IAS_STABLE'] =1
    return df

def add_over_12months_col(df, months_col):
    df['EC_OVER_12MONTHS']=0
    df.loc[(df[months_col]>12),'EC_OVER_12MONTHS'] =1
    return df

def add_cohort_columns(df, vl_count_col, rna_col, sequence_col, months_col):
    df = add_first_visit_col(df,sequence_col)
    df = add_first_6months_col(df,sequence_col,months_col)
    df = add_first_12months_col(df,months_col)
    df = add_7_to_12months_col(df,months_col)
    df = add_IAS_stable_patient_col(df,vl_count_col, rna_col, months_col)
    df = add_all_col(df)
    return df

def add_visit_cohort_columns(df, sequence_col, months_col):
    df = add_first_visit_col(df,sequence_col)
    df = add_first_6months_col(df,sequence_col,months_col)
    df = add_first_12months_col(df,months_col)
    df = add_7_to_12months_col(df,months_col)
    df = add_over_12months_col(df,months_col)
    df = add_all_col(df)
    return df


def add_visit_archetypes(df,TARGET, late_last_visit_col, late_this_visit_col, visits_at_this_fac_col,
                         months_since_first_visit_col, months_since_last_visit_col,
                         more_than_28_days_late_count_col):
    df = add_AT_LATE_TWICE(df,TARGET, late_last_visit_col, late_this_visit_col)
    df = add_AT_PROMT_LOYAL(df,TARGET, late_this_visit_col, visits_at_this_fac_col, months_since_first_visit_col)
    #df = add_AT_SHOPPER_NONUMBER (df,TARGET, FACILITY_COMPOSITION_col)
    df = add_AT_RETURNING_DEFAULTER (df,TARGET, more_than_28_days_late_count_col, months_since_last_visit_col)
    return df

def show_archetype_stats(string, df, TARGET):
    print(string,' population prevelance:',df[string].value_counts(normalize=True)[1].round(2) , 
          "n = ",df[string].value_counts()[1])
    print(string,' TARGET prevelance:',df[df[string]==1][TARGET].value_counts(normalize=True)[1].round(2) )

def add_AT_LATE_TWICE(df,TARGET, late_last_visit_col, late_this_visit_col):
    string = 'AT_LATE_TWICE'
    df[string] = 0
    df.loc[(df[late_last_visit_col]==1)&(df[late_this_visit_col]==1),string] = 1
    show_archetype_stats(string, df, TARGET)
    
    return df

def add_AT_PROMT_LOYAL(df, TARGET, late_this_visit_col, visits_at_this_fac_col, months_since_first_visit_col):
    string = 'AT_PROMT_LOYAL'
    df[string] = 0
    df.loc[(df[late_this_visit_col]==0)
           &(df[visits_at_this_fac_col]>=(df[months_since_first_visit_col]-1))
           ,string] = 1
    show_archetype_stats(string, df, TARGET)
    
    return df

# def add_AT_SHOPPER_NONUMBER (df,TARGET):
#     string = 'AT_SHOPPER_NONUMBER'
#     df[string] = 0
#     df.loc[(df.V_EF_FACILITY_COMPOSITION<0.89)&(df.P_EF_HAS_PHONE_NUMBER==0)
#            ,string] = 1
#     show_archetype_stats(string, df, TARGET)
    
    return df

def add_AT_RETURNING_DEFAULTER (df,TARGET, more_than_28_days_late_count_col, months_since_last_visit_col):
    string = 'AT_RETURNING_DEFAULTER'
    df[string] = 0
    df.loc[(df[more_than_28_days_late_count_col]>=1)&(df[months_since_last_visit_col]>1),string] = 1
    
    show_archetype_stats(string, df, TARGET)
    
    return df