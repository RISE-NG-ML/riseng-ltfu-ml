import pandas as pd
import datetime as dt
import numpy as np
from datetime import timedelta

def missed_visit_target(df,LAST_EXPECTED_VISIT):
    if df is not None:
        try:
            df['T_MISSED_NEXT_VISIT_7'] = (df['EF_DAYS_BETWEEN_NEXT_APPOINTMENT_AND_ACTUAL_VISIT_DATE'] > np.timedelta64(7, 'D')) | ((pd.isnull(df['EF_NEXT_ACTUAL_VISIT_DATE'])) & (df['EF_NEXT_APPOINTMENT'] <= LAST_EXPECTED_VISIT)).astype(int)
            df['T_MISSED_NEXT_VISIT_28'] = (df['EF_DAYS_BETWEEN_NEXT_APPOINTMENT_AND_ACTUAL_VISIT_DATE'] > np.timedelta64(28, 'D')) | ((pd.isnull(df['EF_NEXT_ACTUAL_VISIT_DATE'])) & (df['EF_NEXT_APPOINTMENT'] <= LAST_EXPECTED_VISIT)).astype(int)
            df['T_MISSED_NEXT_VISIT_60'] = (df['EF_DAYS_BETWEEN_NEXT_APPOINTMENT_AND_ACTUAL_VISIT_DATE'] > np.timedelta64(60, 'D')) | ((pd.isnull(df['EF_NEXT_ACTUAL_VISIT_DATE'])) & (df['EF_NEXT_APPOINTMENT'] <= LAST_EXPECTED_VISIT)).astype(int)
            df['T_MISSED_NEXT_VISIT_90'] = (df['EF_DAYS_BETWEEN_NEXT_APPOINTMENT_AND_ACTUAL_VISIT_DATE'] > np.timedelta64(90, 'D')) | ((pd.isnull(df['EF_NEXT_ACTUAL_VISIT_DATE'])) & (df['EF_NEXT_APPOINTMENT'] <= LAST_EXPECTED_VISIT)).astype(int)
            return df
        except Exception as e:
            print(f"Exception on generating missed next visit target feature with error: {e}")
        
def next_visit_target(df,LAST_EXPECTED_VISIT,patient_id_col = 'PATIENT_ID',visit_date_col = 'DATE_VISIT'):
    if df is not None:
        try:
            df['T_DAYS_UNTIL_ACTUAL_VISIT_DATE'] = (df['EF_NEXT_ACTUAL_VISIT_DATE'] - df[visit_date_col]).dt.days 
            df['T_NEXT_VISIT_FURTHER_THAN_60_DAYS'] = (df['T_DAYS_UNTIL_ACTUAL_VISIT_DATE'] > 60) | ((pd.isnull(df['EF_NEXT_ACTUAL_VISIT_DATE'])) & 
                                             ((df[visit_date_col] + timedelta(days=60)) <= LAST_EXPECTED_VISIT)).astype(int)
            return df
        except Exception as e:
            print(f"Exception on generating next visit target feature with error: {e}")
            
def last_visit_target(df,LAST_EXPECTED_VISIT, visit_date_col="DATE_VISIT",num_days = 90):
    if df is not None:
        try:
            df["T_IS_LAST_VISIT"] = (df["EF_NEXT_ACTUAL_VISIT_DATE"].isnull()) & (
                (df[visit_date_col] + timedelta(days=num_days)) <= LAST_EXPECTED_VISIT
            ).astype(int)
            return df
        except Exception as e:
            print(f"Exception on generating next visit target feature with error: {e}")
            
def rise_missed_visit_target(df,LAST_EXPECTED_VISIT):
    if df is not None:
        try:
            df['T_MISSED_NEXT_VISIT_7_RISE'] = (df['EF_DAYS_BETWEEN_MEDS_CONSUMED_AND_ACTUAL_VISIT_DATE'] > np.timedelta64(7, 'D')) | ((pd.isnull(df['EF_NEXT_ACTUAL_VISIT_DATE'])) & (df['EF_MEDS_CONSUMED_DATE'] <= LAST_EXPECTED_VISIT)).astype(int)
            df['T_MISSED_NEXT_VISIT_28_RISE'] = (df['EF_DAYS_BETWEEN_MEDS_CONSUMED_AND_ACTUAL_VISIT_DATE'] > np.timedelta64(28, 'D')) | ((pd.isnull(df['EF_NEXT_ACTUAL_VISIT_DATE'])) & (df['EF_MEDS_CONSUMED_DATE'] <= LAST_EXPECTED_VISIT)).astype(int)
            df['T_MISSED_NEXT_VISIT_60_RISE'] = (df['EF_DAYS_BETWEEN_MEDS_CONSUMED_AND_ACTUAL_VISIT_DATE'] > np.timedelta64(60, 'D')) | ((pd.isnull(df['EF_NEXT_ACTUAL_VISIT_DATE'])) & (df['EF_MEDS_CONSUMED_DATE'] <= LAST_EXPECTED_VISIT)).astype(int)
            df['T_MISSED_NEXT_VISIT_90_RISE'] = (df['EF_DAYS_BETWEEN_MEDS_CONSUMED_AND_ACTUAL_VISIT_DATE'] > np.timedelta64(90, 'D')) | ((pd.isnull(df['EF_NEXT_ACTUAL_VISIT_DATE'])) & (df['EF_MEDS_CONSUMED_DATE'] <= LAST_EXPECTED_VISIT)).astype(int)
            return df
        except Exception as e:
            print(f"Exception on generating missed next visit target feature with error: {e}")
            
def target_baselines(df):
    days_7 = round(
        df[df["T_MISSED_NEXT_VISIT_7"] == True].shape[0] / df.shape[0] * 100, 2
    )
    days_28 = round(
        df[df["T_MISSED_NEXT_VISIT_28"] == True].shape[0] / df.shape[0] * 100, 2
    )
    days_60 = round(
        df[df["T_MISSED_NEXT_VISIT_60"] == True].shape[0] / df.shape[0] * 100, 2
    )
    days_90 = round(
        df[df["T_MISSED_NEXT_VISIT_90"] == True].shape[0] / df.shape[0] * 100, 2
    )
    print(f"> 7 days late: {days_7}%\n> 28 days late: {days_28}%")
    print(f"> 60 days Late: {days_60}%\n> 90 days late: {days_90}%")
    return 

def generate_visit_targets(df,id_col, visit_dates, LAST_EXPECTED_VISIT):
    print('Generating missed_visit_target')
    df = missed_visit_target(df,LAST_EXPECTED_VISIT)
    print('Generating next_visit_target')
    df = next_visit_target(df, LAST_EXPECTED_VISIT)
    print('Generating last_visit_target')
    df = last_visit_target(df, LAST_EXPECTED_VISIT)
    print('Calculating target baselines')
    target_baselines(df)

    print('Done!')
    return df