import pandas as pd
import datetime as dt
import numpy as np
import math
from datetime import timedelta

def create_last_facility_codes_EF(df, id_field = 'PATIENT_ID', visit_field = 'DATE_VISIT'):
    df = df.sort_values(by=[id_field, visit_field])
    df['EF_LAST_FACILITY_ID'] = df.groupby([id_field])['EF_FACILITY_ID'].shift(1).fillna(-1).astype('int8')
    df['EF_DIFFERENT_LAST_FACILIITY'] = -1
    df.loc[df['EF_FACILITY_ID']==df['EF_LAST_FACILITY_ID'],'EF_DIFFERENT_LAST_FACILIITY'] = 0
    df.loc[(df['EF_FACILITY_ID']!=df['EF_LAST_FACILITY_ID'])&(df['EF_LAST_FACILITY_ID']!=-1),'EF_DIFFERENT_LAST_FACILIITY'] = 1
    df['EF_DIFFERENT_LAST_FACILIITY'] = df['EF_DIFFERENT_LAST_FACILIITY'].astype('int8')
    return df

def days_months_since_visit_features(df,visit_date_col = 'DATE_VISIT',patient_id_col = 'PATIENT_ID'):
    if df is not None:
        try:
            df['EF_LAST_VISIT_DATE'] = df.groupby(patient_id_col)[visit_date_col].shift(1)
            df['EF_LAST_VISIT_DATE'] = df['EF_LAST_VISIT_DATE'].fillna(df[visit_date_col])
            df['EF_DAYS_SINCE_LAST_VISIT'] = ((df[visit_date_col] - df['EF_LAST_VISIT_DATE'])/np.timedelta64(1, 'D'))
            df['EF_DAYS_SINCE_LAST_VISIT'] = df['EF_DAYS_SINCE_LAST_VISIT'].fillna(0).astype(int)
            df['EF_MONTHS_SINCE_LAST_VISIT'] = ((df[visit_date_col] - df['EF_LAST_VISIT_DATE'])/np.timedelta64(1, 'M'))
            df['EF_MONTHS_SINCE_LAST_VISIT'] = df['EF_MONTHS_SINCE_LAST_VISIT'].fillna(0).astype(int)
            df.loc[df['EF_MONTHS_SINCE_LAST_VISIT'] < 0,'EF_MONTHS_SINCE_LAST_VISIT'] = -1
            df.loc[df['EF_DAYS_SINCE_LAST_VISIT'] < 0,'EF_DAYS_SINCE_LAST_VISIT'] = -1
            return df
        except Exception as e:
            print(f"Exception on generating days/months since last visit with error: {e}") 
            
def days_late_features(df,patient_id_col = 'PATIENT_ID'):
    if df is not None:
        try:
            df['EF_DAYS_LATE'] = df.groupby(patient_id_col)['EF_DAYS_BETWEEN_NEXT_APPOINTMENT_AND_ACTUAL_VISIT_DATE'].shift(1)
            df['EF_DAYS_LATE'] = df['EF_DAYS_LATE'].fillna(pd.Timedelta(days=-1)) 
            df['EF_WAS_MORE_THAN_3_DAYS_LATE'] = df['EF_DAYS_LATE'] > np.timedelta64(3, 'D')
            df['EF_WAS_MORE_THAN_28_DAYS_LATE'] = df['EF_DAYS_LATE'] > np.timedelta64(28, 'D')
            df['EF_WAS_MORE_THAN_60_DAYS_LATE'] = df['EF_DAYS_LATE'] > np.timedelta64(60, 'D')
            df['EF_WAS_MORE_THAN_90_DAYS_LATE'] = df['EF_DAYS_LATE'] > np.timedelta64(90, 'D')
            return df
        except Exception as e:
            print(f"Exception on generating days late with error: {e}")

def meds_days_late_features(df,patient_id_col = 'PATIENT_ID'):
    if df is not None:
        try:
            df['EF_DAYS_LATE_MEDS'] = df.groupby(patient_id_col)['EF_DAYS_BETWEEN_MEDS_CONSUMED_AND_ACTUAL_VISIT_DATE'].shift(1)
            df['EF_DAYS_LATE_MEDS'] = df['EF_DAYS_LATE_MEDS'].fillna(pd.Timedelta(days=-1)) 
            df['EF_WAS_MORE_THAN_3_DAYS_LATE_MEDS'] = df['EF_DAYS_LATE_MEDS'] > np.timedelta64(3, 'D')
            df['EF_WAS_MORE_THAN_28_DAYS_LATE_MEDS'] = df['EF_DAYS_LATE_MEDS'] > np.timedelta64(28, 'D')
            df['EF_WAS_MORE_THAN_60_DAYS_LATE_MEDS'] = df['EF_DAYS_LATE_MEDS'] > np.timedelta64(60, 'D')
            df['EF_WAS_MORE_THAN_90_DAYS_LATE_MEDS'] = df['EF_DAYS_LATE_MEDS'] > np.timedelta64(90, 'D')
            return df
        except Exception as e:
            print(f"Exception on generating days late with error: {e}")
            
def late_last_visit_feature(df, patient_id_col = 'PATIENT_ID'):
    if df is not None:
        try:
            df['EF_LATE_LAST_VISIT'] = df['EF_LATE_THIS_VISIT'].astype('int')
            df['EF_LATE_LAST_VISIT'] = df.groupby(patient_id_col)['EF_LATE_LAST_VISIT'].shift(1)
            df['EF_LATE_LAST_VISIT'] = df['EF_LATE_LAST_VISIT'].fillna(-1)
            return df
        except Exception as e:
            print(f"Exception on generating late last feature with error: {e}") 
            
def meds_late_last_visit_feature(df, patient_id_col = 'PATIENT_ID'):
    if df is not None:
        try:
            df['EF_LATE_LAST_VISIT_MEDS'] = df['EF_LATE_THIS_VISIT_MEDS'].astype('int')
            df['EF_LATE_LAST_VISIT_MEDS'] = df.groupby(patient_id_col)['EF_LATE_LAST_VISIT_MEDS'].shift(1)
            df['EF_LATE_LAST_VISIT_MEDS'] = df['EF_LATE_LAST_VISIT_MEDS'].fillna(-1)
            return df
        except Exception as e:
            print(f"Exception on generating late last feature with error: {e}") 
            
def next_actual_visit_features(df,patient_id_col = 'PATIENT_ID',visit_date_col = 'DATE_VISIT'):
    if df is not None:
        try:
            df['EF_NEXT_ACTUAL_VISIT_DATE'] = df.groupby(patient_id_col)[visit_date_col].shift(-1)
            df['EF_DAYS_BETWEEN_NEXT_APPOINTMENT_AND_ACTUAL_VISIT_DATE'] = df['EF_NEXT_ACTUAL_VISIT_DATE'] - df['EF_NEXT_APPOINTMENT']
            df['EF_DAYS_BETWEEN_MEDS_CONSUMED_AND_ACTUAL_VISIT_DATE'] = df['EF_NEXT_ACTUAL_VISIT_DATE'] - df['EF_MEDS_CONSUMED_DATE']
            return df
        except Exception as e:
            print(f"Exception on generating next visit target feature with error: {e}")
            
def late_days_count_ratio_features(df, num_days_late,patient_id_col = 'PATIENT_ID'):
    if df is not None:
        try:
            df['EF_MORE_THAN_'+str(num_days_late)+'_DAYS_LATE_COUNT'] = df.groupby(patient_id_col)['EF_WAS_MORE_THAN_'+str(num_days_late)+'_DAYS_LATE'].apply(lambda x: x.fillna(1).cumsum()).astype(int)
            df['EF_MORE_THAN_'+str(num_days_late)+'_DAYS_LATE_RATIO'] = df['EF_MORE_THAN_'+str(num_days_late)+'_DAYS_LATE_COUNT']/df['EF_ID_SEQUENCE']
            return df
        except Exception as e:
            print(f"Exception on generating late days count ratio feature with error: {e}")
            
def meds_late_days_count_ratio_features(df, num_days_late,patient_id_col = 'PATIENT_ID'):
    if df is not None:
        try:
            df['EF_MORE_THAN_'+str(num_days_late)+'_DAYS_LATE_COUNT_MEDS'] = df.groupby(patient_id_col)['EF_WAS_MORE_THAN_'+str(num_days_late)+'_DAYS_LATE_MEDS'].apply(lambda x: x.fillna(1).cumsum()).astype(int)
            df['EF_MORE_THAN_'+str(num_days_late)+'_DAYS_LATE_RATIO_MEDS'] = df['EF_MORE_THAN_'+str(num_days_late)+'_DAYS_LATE_COUNT_MEDS']/df['EF_ID_SEQUENCE']
            return df
        except Exception as e:
            print(f"Exception on generating late days count ratio feature with error: {e}")
            
def months_first_visit_features(df,visit_date_col = 'DATE_VISIT'):
    if df is not None:
        try:
            df['EF_MONTHS_SINCE_FIRST_VISIT'] = ((df[visit_date_col] - df['EF_FIRST_DATE_VISIT'])/np.timedelta64(1, 'M'))
            df['EF_MONTHS_SINCE_FIRST_VISIT'] = df['EF_MONTHS_SINCE_FIRST_VISIT'].fillna(0).astype(int)
            return df
        except Exception as e:
            print(f"Exception on generating late days count ratio feature with error: {e}")
            
def format_shape(df, unique_id = None):
#     ri = 'rows:' + format(len(df.index),',') + ' cols: ' + format(len(df.columns),',')
    ri = 'rows:' + "{:,}".format(len(df.index)) + '; cols: ' + "{:,}".format(len(df.columns))
    if (unique_id == None):
        return ri
    else:
        ui = "Unique: " + "{:,}".format(df[unique_id].nunique()) 
        return ui +'; ' + ri
    return ri

def get_season(mydate):
    if mydate is not None:
        try:
            season = 0
            dayofyear = mydate.timetuple().tm_yday
            spring = range(80,172)
            summer = range(172,264)
            autumn = range(264,355)
            if dayofyear in spring:
                season = 1
            elif dayofyear in summer:
                season = 2
            elif dayofyear in autumn:
                season = 3
            else:
                season = 4
            return season
        except Exception as e:
            print(f"Exception on extracting season with error:{e}")
            
def generate_date_features(input_df, col_name, capitalize = True):
    print('Generating features for '+ col_name +', starting with ', format_shape(input_df))

    if capitalize:
        #     print(input_df[col_name].dt.year)
        input_df['EF_YEAR_'+col_name] = input_df[col_name].dt.year
        input_df['EF_MONTH_'+col_name] = input_df[col_name].dt.month
        input_df['EF_ISSTARTOFMONTH_'+col_name] = input_df[col_name].dt.is_month_start.astype('float')
        input_df['EF_ISENDOFMONTH_'+col_name] = input_df[col_name].dt.is_month_end.astype('float')
        input_df['EF_DAYOFMONTH_'+col_name] = input_df[col_name].dt.day
        input_df['EF_DAYOFWEEK_'+col_name] = input_df[col_name].dt.weekday
        input_df['EF_ISWEEKEND_'+col_name] = input_df['EF_DAYOFWEEK_'+col_name].map(lambda x: x>4).astype('float')
        input_df['EF_WEEKOFMONTH_'+col_name] = (input_df[col_name].dt.day/7).astype(int) + 1
        input_df['EF_QUARTER_'+col_name] = input_df[col_name].dt.quarter
        input_df['EF_ISSTARTOFQUARTER_'+col_name] = input_df[col_name].dt.is_quarter_start.astype(float)
        input_df['EF_ISENDOFQUARTER_'+col_name] = input_df[col_name].dt.is_quarter_end.astype(float)
        input_df['EF_SEASON_'+col_name] = input_df[col_name].apply(get_season)
    else:
        input_df['ef_year_'+col_name] = input_df[col_name].dt.year
        input_df['ef_month_'+col_name] = input_df[col_name].dt.month
        input_df['ef_isstartofmonth_'+col_name] = input_df[col_name].dt.is_month_start.astype('float')
        input_df['ef_isendofmonth_'+col_name] = input_df[col_name].dt.is_month_end.astype('float')
        input_df['ef_dayofmonth_'+col_name] = input_df[col_name].dt.day
        input_df['ef_dayofweek_'+col_name] = input_df[col_name].dt.weekday
        input_df['ef_isweekend_'+col_name] = input_df['ef_dayofweek_'+col_name].map(lambda x: x>4).astype('float')
        input_df['ef_weekofmonth_'+col_name] = (input_df[col_name].dt.day/7).astype(int) + 1
        input_df['ef_quarter_'+col_name] = input_df[col_name].dt.quarter
        input_df['ef_isstartofquarter_'+col_name] = input_df[col_name].dt.is_quarter_start.astype(float)
        input_df['ef_isendofquarter_'+col_name] = input_df[col_name].dt.is_quarter_end.astype(float)
        input_df['ef_season_'+col_name] = input_df[col_name].apply(get_season)
        
    print('Generating features for '+ col_name +',ending with ', format_shape(input_df))
        
    return input_df