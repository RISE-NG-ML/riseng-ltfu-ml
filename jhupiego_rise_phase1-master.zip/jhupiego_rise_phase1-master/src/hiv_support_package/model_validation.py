import pandas as pd
import numpy as np
from sklearn import metrics
import matplotlib.pyplot as plt
import seaborn as sns
import random

def gini_score(a, b):
    """Function that received two parameters; 
    a: a binary variable representing 0=good and 1=bad, and then a second variable with the prediction of the first variable, 
    b: the second variable can be continuous, integer or binary - continuous is better. 
    Finally, the function returns the GINI Coefficient of the two lists."""

    gini_metric = 2*metrics.roc_auc_score(a, b)-1
    return gini_metric


def evaluate_model(model, predictions, probs, y_train, X_test, y_test, T_labels=None, normalise_conf_mtx=None):
    """
    Binary classification model validation metrics & visualisations

    To normalise confusion matrix specify normalise_conf_mtx as 'true' (string, not bool)
    """


    y_train_0 ,y_train_1 = pd.Series(y_train).value_counts()
    y_test_0 ,y_test_1 = pd.Series(y_test).value_counts()
    y_train_0_norm ,y_train_1_norm = pd.Series(y_train).value_counts(normalize=True)
    y_test_0_norm ,y_test_1_norm = pd.Series(y_test).value_counts(normalize=True)

    #print(f'Train set:\n{}\n{}\nTest set:\n{}')
    print('Train set target distribution:\n',y_train_0,y_train_0_norm,'\n',y_train_1,y_train_1_norm,'\n')
    print('Test set target distribution:\n',y_test_0,round(y_test_0_norm,2),'\n',y_test_1,round(y_test_1_norm,2),'\n\n')

    #Calculate classification metrics
    f1 = round(metrics.f1_score(y_test, predictions), 3)
    accuracy = round(metrics.accuracy_score(y_test, predictions), 3)
    precision = round(metrics.precision_score(y_test, predictions), 3)
    recal = round(metrics.recall_score(y_test, predictions), 3)
    roc_auc = round(metrics.roc_auc_score(y_test, probs), 3)
    (tn, fp), (fn, tp) = metrics.confusion_matrix(y_test, predictions)
    specificity = round(tn/(tn+fp), 3)
    mcc = round(metrics.matthews_corrcoef(y_test, predictions), 3)
    gini = round(gini_score(y_test,probs),3)
    PR_AUC = round(metrics.average_precision_score(y_test, predictions), 3)
    brier_loss_score = round(metrics.brier_score_loss(y_test, probs), 3)
                        
    print("Metrics:\n  f1: %s" % f1)
    print("  MCC: %s" % mcc)
    print("  accuracy: %s" % accuracy)
    print("  specificity: %s" % specificity)
    print("  precision: %s" % precision)
    print("  recal: %s" % recal)
    print("  roc_auc: %s" % roc_auc)
    print("  GINI: %s" % gini)
    print("  PR_AUC: %s" % PR_AUC)
    print("  Brier_loss: %s" % brier_loss_score)
    print("\nClassification report:\n %s" % metrics.classification_report(y_test, predictions, target_names=T_labels))
    
    # Calculate false positive rates and true positive rates (roc curve & baseline)
    base_fpr, base_tpr, _ = metrics.roc_curve(y_test, [1 for _ in range(len(y_test))])
    model_fpr, model_tpr, _ = metrics.roc_curve(y_test, probs)
    
    plt.figure(figsize = (8, 6))

    plt.rcParams['font.size'] = 16
    
    # Plot both curves (roc)
    plt.plot(base_fpr, base_tpr, 'b', label = 'baseline')
    plt.plot(model_fpr, model_tpr, 'r', label = f'model AUC={round(metrics.roc_auc_score(y_test, probs),2)}')
    plt.legend();
    plt.xlabel('False Positive Rate'); plt.ylabel('True Positive Rate'); plt.title('ROC Curves');
    plt.show()

    # Plot Precision-Recall curve
    print('Precision Recall Curve')
    precisions, recalls, thresholds = metrics.precision_recall_curve(y_test, probs)
    print(f'Precision Recall AUC = {PR_AUC}')
    metrics.PrecisionRecallDisplay(precisions, recalls).plot()

    
    # Plot confusion matrix
    sns.set(rc={'figure.figsize':(10,6)})
    print('Confusion matrix:')
    metrics.plot_confusion_matrix(model, X_test, y_test, normalize=normalise_conf_mtx, display_labels=T_labels, values_format='')
    plt.grid(None)
    print(metrics.confusion_matrix(y_test, predictions))

    return


def random_feature_test(y_train, model, y_test):
    """
    model: instantiated model e.g. 'AdaBoostClassifier()'

    This function create a random binary feature E[0, 1] and trains the model on it, then evaluates model performance 
    on similar test feature. This serves as a baseline to compare other models too
    """
    random_feature_train = np.array(random.sample(list(y_train), y_train.shape[0]))
    random_feature_test = np.array(random.sample(list(y_test), y_test.shape[0]))
    model.fit(random_feature_train.reshape(-1, 1), y_train)
    preds = model.predict(random_feature_test.reshape(-1, 1))
    probs = model.predict_proba(random_feature_test.reshape(-1, 1))[:,1]
    evaluate_model(model, preds, probs, y_train, random_feature_test.reshape(-1, 1), y_test)
    return preds, probs
