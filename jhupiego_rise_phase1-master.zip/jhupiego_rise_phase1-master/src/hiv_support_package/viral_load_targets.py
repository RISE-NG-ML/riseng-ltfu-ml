import numpy as np

def virally_suppressed_target(df, lab_value_col, VIRAL_LOAD_LEVEL, lab_type_col, lab_type):
    if df is not None:
        try:
            df["T_VL_SUPP_" + str(VIRAL_LOAD_LEVEL)] = 0
            df.loc[
                (df[lab_type_col] == lab_type) & (df[lab_value_col] < int(VIRAL_LOAD_LEVEL)),
                "T_VL_SUPP_" + str(VIRAL_LOAD_LEVEL),
            ] = 1
            return df
        except Exception as e:
            print(f"Exception on virally suppressed target creation with error: {e}")
            
def virally_unsuppressed_target(df, lab_value_col, VIRAL_LOAD_LEVEL, lab_type_col, lab_type):
    if df is not None:
        try:
            df["T_VL_UNSUPP_" + str(VIRAL_LOAD_LEVEL)] = 0
            df.loc[
                (df[lab_type_col] == lab_type)
                & (df[lab_value_col] >= int(VIRAL_LOAD_LEVEL)),
                "T_VL_UNSUPP_" + str(VIRAL_LOAD_LEVEL),
            ] = 1
            return df
        except Exception as e:
            print(f"Exception on virally unsuppressed target creation with error: {e}")
            
def virally_undetectable_target(df, lab_value_col, VIRAL_LOAD_LEVEL, lab_type_col, lab_type):
    if df is not None:
        try:
            df["T_VL_UNDETECT_" + str(VIRAL_LOAD_LEVEL)] = 0
            df.loc[
                (df[lab_type_col] == lab_type) & (df[lab_value_col] <= int(VIRAL_LOAD_LEVEL)),
                "T_VL_UNDETECT_" + str(VIRAL_LOAD_LEVEL),
            ] = 1
            return df
        except Exception as e:
            print(f"Exception on virally undetectable target creation with error: {e}")
            
def vl_categorization_rise_target(df, lab_value_col: str, undetect_bound: int, supp_bound: int):
    """
    0: Undetectable
    1: Suppressed not Undetectable
    2: Unsuppressed
    """
    if df is not None:
        try:
            target_definitions = [
                (df[lab_value_col] <= int(undetect_bound)),
                (df[lab_value_col] > int(undetect_bound))
                & (df[lab_value_col] < int(supp_bound)),
                (df[lab_value_col] >= int(supp_bound)),
            ]
            target_values = [0, 1, 2]
            df["T_RISE_VL_CATEGORIZATION"] = np.select(
                target_definitions, target_values
            )
            return df
        except Exception as e:
            print(f"Exception on generating rise vl load categorized target with error: {e}")