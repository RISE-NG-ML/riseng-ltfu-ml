from numpy import mean
from numpy import var
from math import sqrt
import pandas as pd
import math

def pd_or(independent_series, dependent_series, precision=2):
    ct = pd.crosstab(independent_series, dependent_series)
    a = ct.iloc[1,1]
    b = ct.iloc[1,0]
    c = ct.iloc[0,1]
    d = ct.iloc[0,0]
    _or = (a*d)/(b*c)
    
    return round(_or, precision)

def pd_rr(independent_series, dependent_series, precision=2):
    ct = pd.crosstab(independent_series, dependent_series)
    a = ct.iloc[1,1]
    b = ct.iloc[1,0]
    c = ct.iloc[0,1]
    d = ct.iloc[0,0]
    _rr = (a/(a+b))/(c/(c+d))
    
    return round(_rr, precision)

def pd_rr_standard_error(independent_series, dependent_series, precision=3,
                        confidence_interval = 95):
    ct = pd.crosstab(independent_series, dependent_series)
    a = ct.iloc[1,1]
    b = ct.iloc[1,0]
    c = ct.iloc[0,1]
    d = ct.iloc[0,0]
    _rr = (a/(a+b))/(c/(c+d))
    rr_standard_error = round(math.sqrt(1/a+1/c-1/(a+b)-1/(c+d)),precision)
    #confidence intervals
    #z*–values for Various Confidence Levels
    z={
        80:1.28,
        90:1.645,
        95:1.96,
        98:2.33,
        99:2.58,
    } 
    ci_lower = round(math.exp(math.log(_rr)-(z.get(confidence_interval)*rr_standard_error)),precision)
    ci_upper = round(math.exp(math.log(_rr)+(z.get(confidence_interval)*rr_standard_error)),precision)
    
    return rr_standard_error, ci_lower, ci_upper


def get_rr_table(independent_series, dependent_series, precision = 3,
                confidence_interval = 95):
    _rr = pd_rr(independent_series, dependent_series, precision)
    rr_standard_error, ci_lower, ci_upper = pd_rr_standard_error(
        independent_series, dependent_series, precision, confidence_interval)
    print("RR:",round(_rr, precision),"(", confidence_interval,"% CI:",
          round(ci_lower, precision),"-",round(ci_upper, precision),")")
    return _rr, rr_standard_error, ci_lower, ci_upper


def full_mm_group_analysis(independent_series, dependent_series, control_col, precision = 3):
    display(pd.crosstab(independent_series, dependent_series,margins=True))
        
    _or = pd_or(independent_series, dependent_series)
    print("OR against",control_col,":", _or)
    _rr = pd_rr(independent_series, dependent_series, precision)
    print("RR against",control_col,":", _rr)
    _rr95, rr_standard_error, ci_lower95, ci_upper95 = get_rr_table(
        independent_series, dependent_series, precision,95)
    _rr99, rr_standard_error, ci_lower99, ci_upper99 = get_rr_table(
        independent_series, dependent_series, precision,99)
    print('\n')
    
    return _or, _rr, _rr95, rr_standard_error, ci_lower95, ci_upper95


def show_all_relative_risk_for_all_columns(columns_list, df, control_col, TARGET ):
    sub_df = df[df[control_col]==1]
    control_risk_pct = sub_df[TARGET].value_counts(normalize=True)[1].round(3)
    control_pop_pct = sub_df.shape[0]/len(df)
    results_df = pd.DataFrame(columns=['n', 'Pop%', 'LTFU%', 'Abs','OR','RR','95% CI'])
    control_row = {
            'n':sub_df.shape[0], 
            'Pop%':control_pop_pct, 
            'LTFU%':sub_df[TARGET].value_counts(normalize=True)[1],
            'Abs':'-',
            'OR':1,
            'RR':1,
            '95% CI': '-'}
    
    results_df.loc[control_col] = control_row
    
    for col in columns_list:
        sub_df = df[df[col]==1]
        sub_risk_pct = sub_df[TARGET].value_counts(normalize=True)[1].round(3)
        n = sub_df.shape[0]
        sub_pop = sub_df.shape[0]/len(df)
        if (col != control_col):
            print(col, "n=",n,"Pop%", '{0:.1%} '.format(sub_pop))
            print("LTFU%", '{0:.1%} '.format(sub_risk_pct))
            abs_diff = sub_risk_pct-control_risk_pct
            print("ABS risk diff:", '{0:.1%} '.format(abs_diff))
            controlled_df = df[(df[col]==1)|((df[col]==0)&(df[control_col]==1))]
            _or, _rr, _rr95, rr_standard_error, ci_lower95, ci_upper95 = full_mm_group_analysis(
                controlled_df[col], controlled_df[TARGET], control_col, precision = 3)

            row = {
            'n':n, 
            'Pop%':sub_pop, 
            'LTFU%':sub_risk_pct,
            'Abs':abs_diff,
            'OR':_or,
            'RR':_rr,
            '95% CI': str(ci_lower95)+' - '+str(ci_upper95)}
            
            results_df.loc[col] = row
        
    return results_df
