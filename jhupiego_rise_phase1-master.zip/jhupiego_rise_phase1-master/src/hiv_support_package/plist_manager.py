import pandas as pd
import seaborn as sns
from numpy import var
from numpy import mean
from math import sqrt

import matplotlib.pyplot as plt

# ** UNTIL WE CAN CALL PALINDROME LIB
def pvc(series):
    df = pd.DataFrame(series.value_counts()).join(
        round(series.value_counts(normalize=True),2),rsuffix='_pct').sort_index()
    return df

def plist_add_risk_groups(plist):
    # plist by std_dev tails
    plist['risk_bin_manual'] = 'Yellow'
    plist.loc[plist.pct_n_ordered<=0.15,'risk_bin_manual'] = 'Red'
    plist.loc[plist.pct_n_ordered>=0.5,'risk_bin_manual'] = 'Green'

    # plist by quartile
    plist['risk_bin_quarts'] = 2
    plist.loc[plist.pct_n_ordered<=0.25,'risk_bin_quarts'] = 3
    plist.loc[plist.pct_n_ordered>=0.5,'risk_bin_quarts'] = 1

    # plist by thirds percentage
    plist['risk_bin_thirds'] = 2
    plist.loc[plist.pct_n_ordered<=0.33,'risk_bin_thirds'] = 3
    plist.loc[plist.pct_n_ordered>=0.66,'risk_bin_thirds'] = 1

    # plist by pareto percentage
    plist['risk_bin_pareto'] = 2
    plist.loc[plist.pct_n_ordered<=0.10,'risk_bin_pareto'] = 3
    plist.loc[plist.pct_n_ordered>=0.50,'risk_bin_pareto'] = 1

#     plist['risk_bin_score_manual'] = 2
#     plist.loc[plist[RISK_COL]<=0.496,'risk_bin_score_manual'] = 1
#     plist.loc[plist[RISK_COL]>=0.502,'risk_bin_score_manual'] = 3
    return plist


def riskgroup_target_share_table(plist, risk_group_col,TARGET):
    a = pvc(plist[risk_group_col])
    b = pvc(plist[plist[TARGET]==1][risk_group_col]) 
    c = a.join(b.iloc[:,1], rsuffix='_targetED')
    d = plist.groupby(risk_group_col)[TARGET].value_counts(normalize=True).sort_index().rename('_pos_pct').reset_index()
    d.set_index(risk_group_col, inplace=True)
    d = round(d[d[TARGET]==1]['_pos_pct'],2)
    e = c.join(d).sort_values(by=str(risk_group_col)+'_pct',ascending=False)
    return(e)

def plot_riskgroup_by_target(stack, risk_group_col, TARGET):
    stack[TARGET] = stack[TARGET].map({0: 'Retained', 1: 'IIT'})
    stack = round(stack.groupby(risk_group_col)[TARGET].value_counts(normalize=True),2).sort_index()  
    stack = stack.reset_index(name='pct_of_group').sort_values(by=['pct_of_group'],ascending=False)
    format_dict = { 'pct_of_group': '{:.0%}'}
    display(stack[stack[TARGET]=='IIT'].style.format(format_dict).hide_index())
    g = sns.catplot( x=risk_group_col, hue=TARGET, y='pct_of_group', data=stack, kind="bar",height=4, aspect=1.23, palette="RdBu_r")  

def compare_median_baseline_and_cohorts(cohort_baseline,cohort_a, cohort_b,a_name ="a", b_name ="b"):
    baseline_median = pd.DataFrame(cohort_baseline.median()).round(2)
    baseline_median = baseline_median.rename(columns={0: "Median_base"})

    a_median = pd.DataFrame(cohort_a.median()).round(2)
    a_name = "Median_"+a_name
    a_median = a_median.rename(columns={0: a_name})
    compare_df = pd.concat([baseline_median,a_median], axis=1)

    if (~cohort_b.empty):
        b_median = pd.DataFrame(cohort_b.median()).round(2)
        b_name = "Median_"+b_name
        b_median = b_median.rename(columns={0: b_name})
        compare_df = pd.concat([baseline_median,a_median,b_median], axis=1)

    compare_df['delta_a-b'] = (compare_df.iloc[:,1] - compare_df.iloc[:,2]).abs()
    compare_df['delta_a-b_pct_base'] = (compare_df['delta_a-b']/compare_df.iloc[:,0]).round(2)

    compare_df = compare_df.sort_values(by = 'delta_a-b_pct_base',ascending = False)
    return compare_df

def cohend(d1, d2):
    # calculate the size of samples
    n1, n2 = len(d1), len(d2)
    # calculate the variance of the samples
    s1, s2 = var(d1, ddof=1), var(d2, ddof=1)
    # calculate the pooled standard deviation
    s = sqrt(((n1 - 1) * s1 + (n2 - 1) * s2) / (n1 + n2 - 2))
    # calculate the means of the samples
    u1, u2 = mean(d1), mean(d2)
    # calculate the effect size
    if s==0:   #ldv: this was throwing a "ZeroDivisionError: float division by zero" and I didn't have a better idea; I suspect it's only for the target though, where the 'pooled standard deviation' is zero
        s=0.1
    return (u1 - u2) / s

def cohen_d_dataframes(df1, df2,features):
    s1 = pd.Series()
    for col in features:
        cnd = float(abs(round(cohend(df1[col],df2[col]),2)))
        s1 = s1.append(pd.Series({col:cnd}))
    s1 = s1.rename('cohens_d')
    return s1.astype('float32')


def compare_mean_baseline_and_cohorts(cohort_baseline,cohort_a, cohort_b,a_name ="a", b_name ="b"):
    cohort_b = cohort_b.loc[:,~cohort_b.columns.duplicated()]
    cohort_baseline = cohort_baseline.loc[:,~cohort_baseline.columns.duplicated()]
    cohort_a = cohort_a.loc[:,~cohort_a.columns.duplicated()]

    baseline_describe = pd.DataFrame(cohort_baseline.describe()).round(2)
    baseline_mean = pd.DataFrame(baseline_describe.loc['mean',:])
    baseline_mean = baseline_mean.add_suffix('_base')
    a_describe = pd.DataFrame(cohort_a.describe()).round(2)
    a_mean = pd.DataFrame(a_describe.loc['mean',:])
    a_mean = a_mean.add_suffix('_'+a_name)
    compare_df = pd.concat([baseline_mean,a_mean], axis=1)
    
    a_median = pd.DataFrame(a_describe.loc['50%',:])
    a_median = a_median.add_suffix('_'+a_name)
    
    a_std = pd.DataFrame(a_describe.loc['std',:])
    a_std = a_std.add_suffix('_'+a_name)
    
    compare_df = pd.concat([compare_df,a_median,a_std], axis=1)
    

    if (~cohort_b.empty):
        b_describe = pd.DataFrame(cohort_b.describe()).round(2)
        
        b_mean = pd.DataFrame(b_describe.loc['mean',:])
        b_mean = b_mean.add_suffix('_'+b_name)
#         compare_df = pd.concat([compare_df,b_mean], axis=1)
        
        b_median = pd.DataFrame(b_describe.loc['50%',:])
        b_median = b_median.add_suffix('_'+b_name)
#         compare_df = pd.concat([compare_df,b_median], axis=1)

        b_std = pd.DataFrame(b_describe.loc['std',:])
        b_std = b_std.add_suffix('_'+b_name)
        
        compare_df = pd.concat([baseline_mean,a_mean,b_mean,a_median,b_median,a_std,b_std], axis=1)

#     compare_df['delta_a-b'] = (compare_df.iloc[:,1] - compare_df.iloc[:,2]).abs()
#     compare_df['delta_a-b_pct_base'] = (compare_df['delta_a-b']/compare_df.iloc[:,0]).round(2)

#     compare_df = compare_df.sort_values(by = 'delta_a-b_pct_base',ascending = False)
    return compare_df

def run_all_cohort_descriptors(cohort_baseline,cohort_a, cohort_b, cohort_features, a_name ="a", b_name ="b",  distplot = False):
    cohort_b = cohort_b.loc[:,~cohort_b.columns.duplicated()]
    cohort_baseline = cohort_baseline.loc[:,~cohort_baseline.columns.duplicated()]
    cohort_a = cohort_a.loc[:,~cohort_a.columns.duplicated()]

    print('baseline:',cohort_baseline.shape,a_name,":",cohort_a.shape,b_name,":",cohort_b.shape,)
    ab_mean = compare_mean_baseline_and_cohorts(cohort_baseline,cohort_a, cohort_b,a_name,b_name)
    cohens_ab = cohen_d_dataframes(cohort_a, cohort_b,cohort_features)
    ab_mean = ab_mean.join(cohens_ab).sort_values(by='cohens_d',ascending=False)
    display(ab_mean)
    ordered_features = ab_mean.index.tolist()
    for col in ordered_features:
        print(col)
        cohort_b_bins = cohort_b[col].nunique()
        cohort_a_bins = cohort_a[col].nunique()
        cohort_bins = max(cohort_b_bins, cohort_a_bins)
        print(cohort_a_bins)
        
        if distplot:
#     #         sns.distplot(cohort_baseline[col])
#             sns.distplot(cohort_b[col].rename(b_name), rug=True, color="g", bins = cohort_bins, hist_kws={"rwidth":0.5,'edgecolor':'black', 'alpha':0.5})
#             sns.distplot(cohort_a[col].rename(a_name), rug=True, color="r", bins = cohort_bins, hist_kws={"rwidth":0.5,'edgecolor':'black', 'alpha':0.5})
            
            sns.distplot(cohort_b[col].rename(b_name), color="g", rug=True)
            sns.distplot(cohort_a[col].rename(a_name), color="r", rug=True)            
        else:
            sns.kdeplot(cohort_baseline[col])
            sns.kdeplot(cohort_b[col].rename(b_name),shade=True, color="g")
            sns.kdeplot(cohort_a[col].rename(a_name),shade=True, color="r")

#         plt.ticklabel_format(style='sci', axis='both', scilimits=(0,0))
#         RUNS = [-2,-1, 0 1,2,3,4,5]
#         plt.xticks(RUNS)
        plt.show()
def distplot_all(cohort_baseline,cohort_a, cohort_b, cohort_features, a_name ="a", b_name ="b",  distplot = False):
    cohort_b = cohort_b.loc[:,~cohort_b.columns.duplicated()]
    cohort_baseline = cohort_baseline.loc[:,~cohort_baseline.columns.duplicated()]
    cohort_a = cohort_a.loc[:,~cohort_a.columns.duplicated()]
    
    print('baseline:',cohort_baseline.shape,a_name,":",cohort_a.shape,b_name,":",cohort_b.shape,)
    ab_mean = compare_mean_baseline_and_cohorts(cohort_baseline,cohort_a, cohort_b,a_name,b_name)
    cohens_ab = cohen_d_dataframes(cohort_a, cohort_b,cohort_features)
    ab_mean = ab_mean.join(cohens_ab).sort_values(by='cohens_d',ascending=False)
    display(ab_mean)
    ordered_features = ab_mean.index.tolist()
    for col in ordered_features:
        plot_binary(cohort_a, cohort_b, col, True)
#         plt.show()

        
def plot_binary(cohort_a, cohort_b, feature_to_display, convert_neg1_to_0 = False):
    if convert_neg1_to_0:
        cohort_a.loc[cohort_a[feature_to_display] == -1, feature_to_display] = 0
        cohort_b.loc[cohort_b[feature_to_display] == -1, feature_to_display] = 0
        
    cohort_b_bins = cohort_b[feature_to_display].nunique()
    cohort_a_bins = cohort_a[feature_to_display].nunique()
    cohort_bins = max(cohort_b_bins, cohort_a_bins)
    
    a_max = cohort_a[feature_to_display].max()
    b_max = cohort_b[feature_to_display].max()
    
    a_min = cohort_a[feature_to_display].min()
    b_min = cohort_b[feature_to_display].min()
    
    x_max = max(a_max, b_max)
    x_min = min(a_min, b_min)
        
    print('cohort_a value counts')
    display(cohort_a[feature_to_display].value_counts())
    a = cohort_a[cohort_a[feature_to_display]>0][feature_to_display]
    # sns.distplot(cohort_a[feature_to_display].rename('Red'), color="r", rug=True)
    sns.distplot(cohort_a[feature_to_display].rename('Red'), kde=False,norm_hist = True, rug=True, color="r", bins = cohort_bins, hist_kws={"rwidth":1, 'alpha':0.5, "range": [x_min,x_max]})

    print('cohort_b value counts')
    display(cohort_b[feature_to_display].value_counts())
    b = cohort_b[cohort_b[feature_to_display]>0][feature_to_display]
    sns.distplot(cohort_b[feature_to_display].rename('Green'), kde=False, norm_hist = True, rug=True, color="g", bins = cohort_bins, hist_kws={"rwidth":1, 'alpha':0.5, "range": [x_min,x_max]})

    # arr = np.array([0,1])

    # sns.distplot(bins = arr, kde = False)
#     plt.xticks = np.array([0,1])

#     plt.xlim(x_min, x_max)
    plt.show()
    
def plot_continous(cohort_a, cohort_b, feature_to_display, bw = 1):
    print('cohort_a value counts')
    display(cohort_a[feature_to_display].value_counts())
    print('\ncohort_b value counts')
    display(cohort_b[feature_to_display].value_counts())
    
    a = cohort_a[cohort_a[feature_to_display]>0][feature_to_display]
    sns.kdeplot(a,shade=True, color="r",bw=bw)

    b = cohort_b[cohort_b[feature_to_display]>0][feature_to_display]
    sns.kdeplot(b,shade=True, color="g",bw=bw)

    plt.show()
